---
name: portfolio-risk-review
description: Analyze weighted portfolio risk trends, concentration and threshold breaches for a monthly credit-risk review.
---

# Portfolio Risk Review

Use Risk_Training_Dataset.xlsx and its named tables RiskPortfolio, RiskTransactions, RiskThresholds and RiskActions. Review date is Guide!B5. Consult the supplied references in this skill folder. These are fictional training rules, not actual Bajaj policy or regulatory standards.
Read required columns by header. Preserve source values, formulas, IDs and tables. Never silently repair source records. Flag invalid or missing inputs. Create a new output worksheet; if it already exists, ask whether to replace it or create a new dated version.
Use formulas linked to source ranges for calculations. Explain any output that is a generated static snapshot and must be rerun after source changes. Do not introduce external data or execute actions outside the workbook. Never use an em dash.

## Workflow
1. Read DATA01 and use the latest portfolio month no later than Guide!B5. Validate unique month-product-region keys, non-negative amounts and bucket reconciliation. Surface errors before interpreting affected rows.
2. Create Portfolio Review. Summarize each month using summed balances and summed dues/receipts. Calculate 30+ and 90+ exposure rates and collection efficiency from matching totals. Do not sum monthly stocks or average percentages.
3. Compare latest with first month and previous month. Show absolute exposure changes, rate changes in percentage points and the formula basis. Keep size and rate effects separate.
4. For the latest month, show total, product, region and product-region metrics. Apply K01-K03 at each documented scope. Calculate K04/K05 shares against the entire same-month portfolio. Apply inclusive Red before Amber boundaries; missing inputs are Not assessable.
5. Show breach counts by metric/scope and unique affected product-region segments separately. Rank latest segments by 30+ delinquent amount, with rates alongside amounts. Do not sum overlapping scopes as separate exposure.
6. Add a month-by-month 30+ rate chart using the calculated table. Label the time period and percentage axis. Draft concise observations with source IDs and questions for further investigation. Do not infer causality, roll rates, vintages, NPA classification or overall risk scores from missing inputs.
7. Verify aggregate ratios against source sums, concentration shares within each month summing to 100%, and representative threshold boundaries. Keep invalid data visible.
