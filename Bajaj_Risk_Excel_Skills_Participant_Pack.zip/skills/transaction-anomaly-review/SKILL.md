---
name: transaction-anomaly-review
description: Flag payment review candidates using explicit high-value, rolling-velocity and shared-device rules, with traceable evidence and no fraud verdict.
---

# Transaction Anomaly Review

Use Risk_Training_Dataset.xlsx and its named tables RiskPortfolio, RiskTransactions, RiskThresholds and RiskActions. Review date is Guide!B5. Consult the supplied references in this skill folder. These are fictional training rules, not actual Bajaj policy or regulatory standards.
Read required columns by header. Preserve source values, formulas, IDs and tables. Never silently repair source records. Flag invalid or missing inputs. Create a new output worksheet; if it already exists, ask whether to replace it or create a new dated version.
Use formulas linked to source ranges for calculations. Explain any output that is a generated static snapshot and must be rerun after source changes. Do not introduce external data or execute actions outside the workbook. Never use an em dash.

## Workflow
1. Read FR01 in references and DATA01. Validate unique Transaction IDs, timestamps, amounts and identifiers. Retain invalid events in a data-quality section; do not silently drop them.
2. Create Transaction Review. Evaluate F01, F02 and F03 exactly as specified for successful events. Evaluate the 10-minute inclusive rolling window using timestamps, including the current event. Count distinct accounts for shared devices across the supplied sample.
3. For each evaluation event, show rule outcomes (Flagged, Not flagged or Not assessable), amount-to-median ratio, successful-event window count and device distinct-account count as applicable. A missing F01 baseline does not suppress F02/F03 evaluation.
4. Produce a deduplicated flagged-event list with all triggered rule IDs, evidence inputs and related window event IDs. Earlier supporting window events do not become independent F02 flags unless they qualify at their own evaluation times.
5. Show eligible successful-event count, per-rule hit counts, unique flagged-event count, unique flagged amount and separate failed-event totals. Reconcile overlaps and distinguish supporting events from flagged events.
6. Describe missing information and legitimate explanations to investigate. Label the output Review candidates. Do not infer intent, confirmed fraud, losses or population fraud prevalence. Do not block or report accounts.
7. Verify the >= boundaries, a missing baseline, failed-event exclusion and the inclusive 10-minute window. If the environment cannot calculate a rule reliably, mark it Not evaluated rather than approximating it without disclosure.
