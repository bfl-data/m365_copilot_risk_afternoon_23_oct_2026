---
name: risk-leadership-summary
description: Prepare a monthly risk leadership summary of KRI exceptions and remediation priorities with explicit evidence gaps.
---

# Risk Leadership Summary

Use Risk_Training_Dataset.xlsx and its named tables RiskPortfolio, RiskTransactions, RiskThresholds and RiskActions. Review date is Guide!B5. Consult the supplied references in this skill folder. These are fictional training rules, not actual Bajaj policy or regulatory standards.
Read required columns by header. Preserve source values, formulas, IDs and tables. Never silently repair source records. Flag invalid or missing inputs. Create a new output worksheet; if it already exists, ask whether to replace it or create a new dated version.
Use formulas linked to source ranges for calculations. Explain any output that is a generated static snapshot and must be rerun after source changes. Do not introduce external data or execute actions outside the workbook. Never use an em dash.

## Workflow
1. Read DATA01 and the policy/threshold references. Create Risk Leadership Summary with the review date and source periods.
2. Recalculate or verify the latest portfolio metrics from source tables. Use weighted ratios and full-portfolio denominators for concentration. Do not rely on stale narrative from earlier output sheets. Report threshold exceptions by scope and metric without adding overlapping exposures.
3. If a Transaction Review exists, verify that its source period and row coverage match the current sample before quoting it. Otherwise mark transaction analysis Pending and recommend running transaction-anomaly-review. Never invent alert counts or confirmed losses.
4. Classify non-Completed actions into Overdue, Due today, Upcoming seven days, Later or Unknown due date. Flag missing owners independently. Keep Completed actions separate and flag absent evidence as a closure-evidence gap. Do not claim independent effectiveness without its evidence.
5. Show a priority table with issue, evidence IDs, recorded owner, original due date, next evidence needed and proposed decision. Mark new roles/actions as proposed. Keep source status unchanged.
6. Draft an executive summary of no more than 150 words and three leadership discussion questions. Separate facts, management assumptions and recommendations. No loan approval, account restriction, policy waiver or regulatory conclusion is authorized by this output.
7. Reconcile action categories to the open-action count, show Completed count separately, and check that no missing-date action appears as zero days overdue. Verify source citations and label narrative as a draft requiring refresh after source edits.
